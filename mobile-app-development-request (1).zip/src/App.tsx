import React, { useState, useCallback } from 'react';
import { Channel, Screen } from './types';
import SplashScreen from './components/SplashScreen';
import LoginScreen from './components/LoginScreen';
import HomeScreen from './components/HomeScreen';
import VideoPlayer from './components/VideoPlayer';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);

  const handleSplashFinish = useCallback(() => {
    setCurrentScreen('login');
  }, []);

  const handleLogin = useCallback((_type: 'xstream' | 'm3u') => {
    setCurrentScreen('home');
  }, []);

  const handlePlayChannel = useCallback((channel: Channel) => {
    setSelectedChannel(channel);
    setCurrentScreen('player');
  }, []);

  const handleBackFromPlayer = useCallback(() => {
    setCurrentScreen('home');
    setSelectedChannel(null);
  }, []);

  const handleLogout = useCallback(() => {
    setCurrentScreen('login');
  }, []);

  return (
    <div className="min-h-screen bg-inci-darker">
      {currentScreen === 'splash' && (
        <SplashScreen onFinish={handleSplashFinish} />
      )}

      {currentScreen === 'login' && (
        <LoginScreen onLogin={handleLogin} />
      )}

      {currentScreen === 'home' && (
        <HomeScreen
          onPlayChannel={handlePlayChannel}
          onLogout={handleLogout}
        />
      )}

      {currentScreen === 'player' && selectedChannel && (
        <VideoPlayer
          channel={selectedChannel}
          onBack={handleBackFromPlayer}
        />
      )}
    </div>
  );
};

export default App;
