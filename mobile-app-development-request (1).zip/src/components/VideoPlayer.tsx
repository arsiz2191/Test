import React, { useState, useEffect, useCallback, useRef } from 'react';
import Hls from 'hls.js';
import {
  Play, Pause, Volume2, VolumeX, Volume1,
  Maximize, Minimize, Settings, ArrowLeft, Sun,
  RotateCcw, RotateCw,
  FastForward, Rewind, Lock, Unlock, X, AlertCircle,
  Loader2, Languages, Check
} from 'lucide-react';
import { Channel } from '../types';

interface Props {
  channel: Channel;
  onBack: () => void;
}

const VideoPlayer: React.FC<Props> = ({ channel, onBack }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(80);
  const [brightness, setBrightness] = useState(100);
  const [showControls, setShowControls] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showSubtitlePanel, setShowSubtitlePanel] = useState(false);
  const [showAudioPanel, setShowAudioPanel] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [aspectRatio, setAspectRatio] = useState<'cover' | 'contain' | 'fill'>('contain');
  const [selectedSubtitle, setSelectedSubtitle] = useState('Kapalı');
  const [selectedAudio, setSelectedAudio] = useState('Türkçe');
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [showBrightnessSlider, setShowBrightnessSlider] = useState(false);
  const [seekPreview, setSeekPreview] = useState<number | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [hlsLevels, setHlsLevels] = useState<{ height: number; bitrate: number }[]>([]);
  const [currentLevel, setCurrentLevel] = useState(-1);
  const [retryCount, setRetryCount] = useState(0);
  const [doubleTapSide, setDoubleTapSide] = useState<'left' | 'right' | null>(null);

  const subtitleOptions = ['Kapalı', 'Türkçe', 'English', 'Deutsch', 'Français', 'Español', 'العربية'];
  const audioOptions = ['Türkçe', 'English', 'Original', 'Deutsch', 'Français'];
  const aspectRatios: { label: string; value: 'cover' | 'contain' | 'fill' }[] = [
    { label: '16:9', value: 'contain' },
    { label: 'Doldur', value: 'cover' },
    { label: 'Tam', value: 'fill' },
  ];
  const speeds = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

  // ── Init HLS / Direct Video ──────────────────────────────────────────────
  const initPlayer = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    // Destroy previous HLS instance
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    setIsLoading(true);
    setHasError(false);
    setHlsLevels([]);
    setCurrentLevel(-1);

    const src = channel.url;

    const onCanPlay = () => setIsLoading(false);
    const onWaiting = () => setIsLoading(true);
    const onPlaying = () => { setIsLoading(false); setIsPlaying(true); };
    const onPause = () => setIsPlaying(false);
    const onTimeUpdate = () => setCurrentTime(video.currentTime);
    const onDurationChange = () => {
      if (video.duration && isFinite(video.duration)) setDuration(video.duration);
    };
    const onError = () => {
      setIsLoading(false);
      setHasError(true);
      setErrorMsg('Video kaynağı yüklenemedi. URL geçerli değil veya bağlantı hatası.');
    };

    video.addEventListener('canplay', onCanPlay);
    video.addEventListener('waiting', onWaiting);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('pause', onPause);
    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('durationchange', onDurationChange);
    video.addEventListener('error', onError);

    const tryAutoPlay = () => {
      video.volume = volume / 100;
      video.muted = false;
      video.play().catch(() => {
        // Autoplay blocked – try muted
        video.muted = true;
        setIsMuted(true);
        video.play().catch(() => {});
      });
    };

    const isHLS = src.includes('.m3u8') || src.includes('m3u8') || src.includes('/live/') || src.includes('stream');

    if (isHLS && Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: channel.isLive,
        backBufferLength: channel.isLive ? 30 : 90,
        maxBufferLength: channel.isLive ? 10 : 30,
        xhrSetup: (xhr) => {
          xhr.withCredentials = false;
        },
      });
      hlsRef.current = hls;
      hls.loadSource(src);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, (_e, data) => {
        setHlsLevels(data.levels.map((l) => ({ height: l.height, bitrate: l.bitrate })));
        setIsLoading(false);
        tryAutoPlay();
      });

      hls.on(Hls.Events.LEVEL_SWITCHED, (_e, data) => setCurrentLevel(data.level));

      hls.on(Hls.Events.ERROR, (_e, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              setIsLoading(false);
              setHasError(true);
              setErrorMsg('HLS akışı yüklenemedi. Kaynak kullanılamıyor olabilir.');
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Safari native HLS
      video.src = src;
      video.addEventListener('loadedmetadata', tryAutoPlay, { once: true });
    } else {
      // Direct MP4 / DASH / RTSP etc.
      video.src = src;
      video.addEventListener('loadedmetadata', tryAutoPlay, { once: true });
    }

    return () => {
      video.removeEventListener('canplay', onCanPlay);
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('durationchange', onDurationChange);
      video.removeEventListener('error', onError);
    };
  }, [channel.url, channel.isLive, retryCount]);

  useEffect(() => {
    const cleanup = initPlayer();
    return () => {
      cleanup?.();
      if (hlsRef.current) { hlsRef.current.destroy(); hlsRef.current = null; }
      if (videoRef.current) { videoRef.current.pause(); videoRef.current.src = ''; }
    };
  }, [initPlayer]);

  // Sync volume
  useEffect(() => {
    if (!videoRef.current) return;
    videoRef.current.volume = isMuted ? 0 : volume / 100;
    videoRef.current.muted = isMuted;
  }, [volume, isMuted]);

  // Sync playback rate
  useEffect(() => {
    if (!videoRef.current) return;
    videoRef.current.playbackRate = playbackRate;
  }, [playbackRate]);

  // Fullscreen listener
  useEffect(() => {
    const onChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onChange);
    return () => document.removeEventListener('fullscreenchange', onChange);
  }, []);

  // Auto-hide controls
  const resetControlsTimer = useCallback(() => {
    if (controlsTimerRef.current) clearTimeout(controlsTimerRef.current);
    controlsTimerRef.current = setTimeout(() => {
      setShowControls(false);
      setShowVolumeSlider(false);
      setShowBrightnessSlider(false);
    }, 4000);
  }, []);

  useEffect(() => {
    if (showControls && !showSettings && !showSubtitlePanel && !showAudioPanel) {
      resetControlsTimer();
    }
    return () => { if (controlsTimerRef.current) clearTimeout(controlsTimerRef.current); };
  }, [showControls, showSettings, showSubtitlePanel, showAudioPanel, resetControlsTimer]);

  // ── Handlers ────────────────────────────────────────────────────────────
  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    v.paused ? v.play().catch(() => {}) : v.pause();
  };

  const seek = (sec: number) => {
    const v = videoRef.current;
    if (!v || channel.isLive) return;
    v.currentTime = Math.max(0, Math.min(v.currentTime + sec, duration));
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressRef.current || channel.isLive || !videoRef.current || !duration) return;
    const rect = progressRef.current.getBoundingClientRect();
    videoRef.current.currentTime = ((e.clientX - rect.left) / rect.width) * duration;
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    document.fullscreenElement
      ? document.exitFullscreen().catch(() => {})
      : containerRef.current.requestFullscreen().catch(() => {});
  };

  const handleDoubleTap = (side: 'left' | 'right') => {
    seek(side === 'left' ? -10 : 10);
    setDoubleTapSide(side);
    setTimeout(() => setDoubleTapSide(null), 700);
  };

  const formatTime = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = Math.floor(s % 60);
    return h > 0
      ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
      : `${m}:${String(sec).padStart(2, '0')}`;
  };

  const VolumeIcon = isMuted || volume === 0 ? VolumeX : volume < 50 ? Volume1 : Volume2;

  const progressPct = duration > 0 ? (currentTime / duration) * 100 : 0;

  // ── Render ───────────────────────────────────────────────────────────────
  return (
    <div
      ref={containerRef}
      className="fixed inset-0 bg-black z-50 select-none overflow-hidden"
      style={{ filter: `brightness(${brightness}%)` }}
    >
      {/* ── Video Element ── */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full"
        style={{ objectFit: aspectRatio }}
        playsInline
        preload="auto"
      />

      {/* ── Loading ── */}
      {isLoading && !hasError && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/70 pointer-events-none">
          <div className="relative mb-5">
            <div className="w-20 h-20 rounded-full border-4 border-red-500/20 border-t-red-500 animate-spin" />
            <div className="absolute inset-0 flex items-center justify-center">
              <Loader2 size={28} className="text-red-400 animate-spin" />
            </div>
          </div>
          <p className="text-white text-base font-bold">{channel.name}</p>
          <p className="text-gray-400 text-sm mt-1">Yükleniyor...</p>
        </div>
      )}

      {/* ── Error ── */}
      {hasError && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/90 px-8">
          <div className="w-20 h-20 rounded-full bg-red-600/20 border border-red-500/30 flex items-center justify-center mb-5">
            <AlertCircle size={40} className="text-red-400" />
          </div>
          <p className="text-white text-xl font-black mb-2">Yayın Yüklenemedi</p>
          <p className="text-gray-400 text-sm mb-2 text-center leading-relaxed">{errorMsg}</p>
          <p className="text-gray-600 text-xs mb-8 text-center">{channel.url}</p>
          <div className="flex gap-3">
            <button
              onClick={() => setRetryCount(c => c + 1)}
              className="px-7 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-black transition-all hover:scale-105 active:scale-95"
            >
              Tekrar Dene
            </button>
            <button
              onClick={onBack}
              className="px-7 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold transition-all"
            >
              Geri Dön
            </button>
          </div>
        </div>
      )}

      {/* ── Touch Areas (double-tap seek) ── */}
      {!isLocked && (
        <>
          <div
            className="absolute left-0 top-0 w-1/3 h-full z-10"
            onClick={() => { setShowControls(p => !p); }}
            onDoubleClick={() => handleDoubleTap('left')}
          />
          <div
            className="absolute left-1/3 top-0 w-1/3 h-full z-10"
            onClick={() => { setShowControls(p => !p); if (!showControls) resetControlsTimer(); }}
          />
          <div
            className="absolute right-0 top-0 w-1/3 h-full z-10"
            onClick={() => { setShowControls(p => !p); }}
            onDoubleClick={() => handleDoubleTap('right')}
          />
        </>
      )}

      {/* ── Double Tap Indicator ── */}
      {doubleTapSide && (
        <div className={`absolute top-1/2 -translate-y-1/2 z-30 pointer-events-none flex flex-col items-center gap-1 ${doubleTapSide === 'left' ? 'left-8' : 'right-8'}`}>
          <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur flex items-center justify-center">
            {doubleTapSide === 'left'
              ? <Rewind size={26} className="text-white" />
              : <FastForward size={26} className="text-white" />
            }
          </div>
          <span className="text-white text-xs font-bold bg-black/50 px-2 py-0.5 rounded-full">
            {doubleTapSide === 'left' ? '-10s' : '+10s'}
          </span>
        </div>
      )}

      {/* ── Locked Screen ── */}
      {isLocked && (
        <div
          className="absolute inset-0 z-30 flex items-center justify-center"
          onClick={() => setShowControls(p => !p)}
        >
          {showControls && (
            <button
              onClick={(e) => { e.stopPropagation(); setIsLocked(false); }}
              className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-xl border border-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <Unlock size={26} className="text-white" />
            </button>
          )}
        </div>
      )}

      {/* ── Mouse move handler ── */}
      <div
        className="absolute inset-0 z-9 pointer-events-none"
        onMouseMove={() => { if (!isLocked) { setShowControls(true); resetControlsTimer(); } }}
        style={{ pointerEvents: showControls ? 'none' : 'auto' }}
      />

      {/* ── Controls Overlay ── */}
      {showControls && !isLocked && !hasError && (
        <div className="absolute inset-0 z-20 flex flex-col pointer-events-none">

          {/* ── Top Bar ── */}
          <div className="pointer-events-auto bg-gradient-to-b from-black/95 via-black/60 to-transparent pt-safe">
            <div className="flex items-center justify-between px-4 py-3">
              {/* Back + Title */}
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <button
                  onClick={onBack}
                  className="flex-shrink-0 w-11 h-11 rounded-2xl bg-white/10 backdrop-blur border border-white/10 flex items-center justify-center hover:bg-white/25 active:scale-95 transition-all"
                >
                  <ArrowLeft size={22} className="text-white" />
                </button>
                <div className="min-w-0">
                  <h2 className="text-white font-black text-sm sm:text-base truncate leading-tight">{channel.name}</h2>
                  <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                    {channel.isLive && (
                      <span className="flex items-center gap-1 text-red-400 text-[10px] font-black">
                        <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" /> CANLI
                      </span>
                    )}
                    {channel.quality && <span className="text-yellow-400 text-[10px] font-black">{channel.quality}</span>}
                    {channel.year && <span className="text-gray-400 text-[10px]">{channel.year}</span>}
                    {playbackRate !== 1 && <span className="text-orange-400 text-[10px] font-black">{playbackRate}x</span>}
                    {hlsLevels.length > 0 && currentLevel >= 0 && hlsLevels[currentLevel] && (
                      <span className="text-green-400 text-[10px] font-bold">{hlsLevels[currentLevel].height}p</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Top Right Buttons */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => setIsLocked(true)}
                  className="w-9 h-9 rounded-xl bg-white/10 backdrop-blur border border-white/10 flex items-center justify-center hover:bg-white/25 transition-colors"
                >
                  <Lock size={15} className="text-white" />
                </button>
                <button
                  onClick={() => { setShowSettings(s => !s); setShowSubtitlePanel(false); setShowAudioPanel(false); }}
                  className={`w-9 h-9 rounded-xl backdrop-blur border flex items-center justify-center transition-colors ${showSettings ? 'bg-red-600 border-red-500' : 'bg-white/10 border-white/10 hover:bg-white/25'}`}
                >
                  <Settings size={15} className="text-white" />
                </button>
              </div>
            </div>
          </div>

          {/* ── Center Controls ── */}
          <div className="flex-1 flex items-center justify-center relative pointer-events-auto">

            {/* Brightness - Left Side */}
            <div className="absolute left-4 top-1/2 -translate-y-1/2 flex flex-col items-center gap-2 z-10">
              <button
                onClick={() => { setShowBrightnessSlider(b => !b); setShowVolumeSlider(false); }}
                className={`w-10 h-10 rounded-2xl backdrop-blur border flex items-center justify-center transition-all ${showBrightnessSlider ? 'bg-yellow-500/30 border-yellow-400/50' : 'bg-white/10 border-white/10 hover:bg-white/20'}`}
              >
                <Sun size={18} className="text-yellow-300" />
              </button>
              {showBrightnessSlider && (
                <div className="flex flex-col items-center bg-black/80 backdrop-blur-xl rounded-2xl p-3 gap-2 border border-white/10">
                  <span className="text-yellow-300 text-xs font-black">{brightness}%</span>
                  <input
                    type="range" min="20" max="150" value={brightness}
                    onChange={e => setBrightness(Number(e.target.value))}
                    className="cursor-pointer accent-yellow-400"
                    style={{ writingMode: 'vertical-lr', direction: 'rtl', height: 100, width: 6 }}
                  />
                  <Sun size={11} className="text-gray-500" />
                </div>
              )}
            </div>

            {/* Main Playback Buttons */}
            <div className="flex items-center gap-4 sm:gap-6">
              {!channel.isLive && (
                <button
                  onClick={() => seek(-30)}
                  className="w-11 h-11 rounded-2xl bg-white/10 backdrop-blur border border-white/10 flex items-center justify-center hover:bg-white/25 active:scale-90 transition-all"
                >
                  <Rewind size={20} className="text-white" />
                </button>
              )}

              {!channel.isLive && (
                <button
                  onClick={() => seek(-10)}
                  className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur border border-white/10 flex items-center justify-center hover:bg-white/25 active:scale-90 transition-all relative"
                >
                  <RotateCcw size={24} className="text-white" />
                  <span className="absolute text-[9px] text-white font-black" style={{ bottom: 8 }}>10</span>
                </button>
              )}

              {/* Play/Pause - Big Button */}
              <button
                onClick={togglePlay}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-red-600 hover:bg-red-500 border-4 border-red-400/40 flex items-center justify-center active:scale-90 transition-all shadow-2xl shadow-red-600/40"
              >
                {isLoading
                  ? <Loader2 size={38} className="text-white animate-spin" />
                  : isPlaying
                    ? <Pause size={36} className="text-white fill-white" />
                    : <Play size={36} className="text-white fill-white ml-1" />
                }
              </button>

              {!channel.isLive && (
                <button
                  onClick={() => seek(10)}
                  className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur border border-white/10 flex items-center justify-center hover:bg-white/25 active:scale-90 transition-all relative"
                >
                  <RotateCw size={24} className="text-white" />
                  <span className="absolute text-[9px] text-white font-black" style={{ bottom: 8 }}>10</span>
                </button>
              )}

              {!channel.isLive && (
                <button
                  onClick={() => seek(30)}
                  className="w-11 h-11 rounded-2xl bg-white/10 backdrop-blur border border-white/10 flex items-center justify-center hover:bg-white/25 active:scale-90 transition-all"
                >
                  <FastForward size={20} className="text-white" />
                </button>
              )}
            </div>

            {/* Volume - Right Side */}
            <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col items-center gap-2 z-10">
              <button
                onClick={() => { setShowVolumeSlider(v => !v); setShowBrightnessSlider(false); }}
                className={`w-10 h-10 rounded-2xl backdrop-blur border flex items-center justify-center transition-all ${showVolumeSlider ? 'bg-red-500/30 border-red-400/50' : 'bg-white/10 border-white/10 hover:bg-white/20'}`}
              >
                <VolumeIcon size={18} className="text-white" />
              </button>
              {showVolumeSlider && (
                <div className="flex flex-col items-center bg-black/80 backdrop-blur-xl rounded-2xl p-3 gap-2 border border-white/10">
                  <span className="text-white text-xs font-black">{isMuted ? 0 : volume}%</span>
                  <input
                    type="range" min="0" max="100" value={isMuted ? 0 : volume}
                    onChange={e => { setVolume(Number(e.target.value)); setIsMuted(false); }}
                    className="cursor-pointer accent-red-500"
                    style={{ writingMode: 'vertical-lr', direction: 'rtl', height: 100, width: 6 }}
                  />
                  <VolumeX size={11} className="text-gray-500" />
                </div>
              )}
            </div>
          </div>

          {/* ── Bottom Bar ── */}
          <div className="pointer-events-auto bg-gradient-to-t from-black/95 via-black/60 to-transparent pb-safe">
            <div className="px-4 pt-4 pb-3">

              {/* Progress Bar */}
              {!channel.isLive && duration > 0 && (
                <div className="mb-3">
                  <div
                    ref={progressRef}
                    className="relative h-1 bg-white/20 rounded-full cursor-pointer group hover:h-2.5 transition-all duration-150 mb-1"
                    onClick={handleProgressClick}
                    onMouseMove={e => {
                      if (!progressRef.current) return;
                      const rect = progressRef.current.getBoundingClientRect();
                      setSeekPreview(Math.floor(((e.clientX - rect.left) / rect.width) * duration));
                    }}
                    onMouseLeave={() => setSeekPreview(null)}
                  >
                    {/* Buffer */}
                    <div className="absolute left-0 top-0 h-full bg-white/15 rounded-full" style={{ width: `${Math.min(progressPct + 8, 100)}%` }} />
                    {/* Played */}
                    <div className="absolute left-0 top-0 h-full bg-red-500 rounded-full transition-all" style={{ width: `${progressPct}%` }} />
                    {/* Thumb */}
                    <div
                      className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-red-500 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity border-2 border-white"
                      style={{ left: `calc(${progressPct}% - 8px)` }}
                    />
                    {/* Seek Preview */}
                    {seekPreview !== null && (
                      <div
                        className="absolute -top-8 bg-black/90 backdrop-blur border border-white/10 px-2 py-0.5 rounded-lg text-xs text-white whitespace-nowrap pointer-events-none"
                        style={{ left: `${(seekPreview / duration) * 100}%`, transform: 'translateX(-50%)' }}
                      >
                        {formatTime(seekPreview)}
                      </div>
                    )}
                  </div>
                  <div className="flex justify-between text-[11px] text-gray-400">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>
              )}

              {/* Live Bar */}
              {channel.isLive && (
                <div className="mb-3 flex items-center gap-3">
                  <div className="flex-1 h-1 bg-red-900/40 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-red-700 to-red-500 rounded-full animate-pulse" style={{ width: '100%' }} />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                    <span className="text-red-400 text-xs font-black tracking-wide">CANLI YAYIN</span>
                  </div>
                </div>
              )}

              {/* Bottom Controls Row */}
              <div className="flex items-center justify-between gap-2">
                {/* Left */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsMuted(m => !m)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 transition-colors border border-white/5"
                  >
                    <VolumeIcon size={15} className="text-white" />
                    <span className="text-xs text-white font-semibold">{isMuted ? 0 : volume}</span>
                  </button>

                  <button
                    onClick={() => { setShowSubtitlePanel(s => !s); setShowAudioPanel(false); setShowSettings(false); }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-colors border ${showSubtitlePanel ? 'bg-red-600/30 border-red-500/50 text-red-300' : 'bg-white/10 border-white/5 hover:bg-white/20 text-white'}`}
                  >
                    <Subtitles size={15} />
                    <span className="text-xs font-semibold hidden sm:inline">Altyazı</span>
                  </button>

                  <button
                    onClick={() => { setShowAudioPanel(a => !a); setShowSubtitlePanel(false); setShowSettings(false); }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-colors border ${showAudioPanel ? 'bg-blue-600/30 border-blue-500/50 text-blue-300' : 'bg-white/10 border-white/5 hover:bg-white/20 text-white'}`}
                  >
                    <Languages size={15} />
                    <span className="text-xs font-semibold hidden sm:inline">Ses</span>
                  </button>
                </div>

                {/* Right */}
                <div className="flex items-center gap-2">
                  {!channel.isLive && (
                    <button
                      onClick={() => { const i = speeds.indexOf(playbackRate); setPlaybackRate(speeds[(i + 1) % speeds.length]); }}
                      className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/5 hover:bg-white/20 transition-colors"
                    >
                      <span className="text-xs text-white font-black">{playbackRate}x</span>
                    </button>
                  )}
                  <button
                    onClick={toggleFullscreen}
                    className="w-9 h-9 rounded-xl bg-white/10 border border-white/5 flex items-center justify-center hover:bg-white/20 transition-colors"
                  >
                    {isFullscreen ? <Minimize size={16} className="text-white" /> : <Maximize size={16} className="text-white" />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* ── Settings Panel ── */}
          {showSettings && (
            <div className="absolute right-4 top-16 w-72 bg-[#0f0f0f]/98 backdrop-blur-2xl rounded-2xl border border-white/10 overflow-hidden z-30 shadow-2xl pointer-events-auto">
              <div className="flex items-center justify-between px-4 py-3 border-b border-white/8">
                <h3 className="text-white font-black text-sm flex items-center gap-2">
                  <Settings size={14} className="text-red-400" /> Oynatıcı Ayarları
                </h3>
                <button onClick={() => setShowSettings(false)} className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/15 transition-colors">
                  <X size={14} className="text-gray-400" />
                </button>
              </div>
              <div className="overflow-y-auto max-h-80">
                {/* Speed */}
                <div className="p-3 border-b border-white/5">
                  <p className="text-gray-500 text-[10px] uppercase tracking-widest font-black mb-2">Oynatma Hızı</p>
                  <div className="grid grid-cols-4 gap-1">
                    {speeds.map(s => (
                      <button key={s} onClick={() => setPlaybackRate(s)}
                        className={`py-2 rounded-xl text-xs font-black transition-colors ${playbackRate === s ? 'bg-red-600 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/12'}`}>
                        {s}x
                      </button>
                    ))}
                  </div>
                </div>
                {/* Aspect Ratio */}
                <div className="p-3 border-b border-white/5">
                  <p className="text-gray-500 text-[10px] uppercase tracking-widest font-black mb-2">En Boy Oranı</p>
                  <div className="grid grid-cols-3 gap-1">
                    {aspectRatios.map(r => (
                      <button key={r.value} onClick={() => setAspectRatio(r.value)}
                        className={`py-2 rounded-xl text-xs font-black transition-colors ${aspectRatio === r.value ? 'bg-red-600 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/12'}`}>
                        {r.label}
                      </button>
                    ))}
                  </div>
                </div>
                {/* HLS Quality */}
                {hlsLevels.length > 0 && (
                  <div className="p-3 border-b border-white/5">
                    <p className="text-gray-500 text-[10px] uppercase tracking-widest font-black mb-2">Video Kalitesi</p>
                    <div className="space-y-1">
                      <button
                        onClick={() => { if (hlsRef.current) hlsRef.current.currentLevel = -1; setCurrentLevel(-1); }}
                        className={`w-full text-left px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-colors ${currentLevel === -1 ? 'bg-red-600/20 text-red-400' : 'text-gray-400 hover:bg-white/5'}`}
                      >
                        <span>🤖 Otomatik</span>
                        {currentLevel === -1 && <Check size={12} className="text-red-400" />}
                      </button>
                      {hlsLevels.map((lvl, i) => (
                        <button key={i}
                          onClick={() => { if (hlsRef.current) hlsRef.current.currentLevel = i; setCurrentLevel(i); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-colors ${currentLevel === i ? 'bg-red-600/20 text-red-400' : 'text-gray-400 hover:bg-white/5'}`}
                        >
                          <span>{lvl.height}p — {(lvl.bitrate / 1000).toFixed(0)}kbps</span>
                          {currentLevel === i && <Check size={12} className="text-red-400" />}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {/* Brightness */}
                <div className="p-3 border-b border-white/5">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-gray-500 text-[10px] uppercase tracking-widest font-black">Parlaklık</p>
                    <span className="text-yellow-400 text-xs font-black">{brightness}%</span>
                  </div>
                  <input type="range" min="20" max="150" value={brightness}
                    onChange={e => setBrightness(Number(e.target.value))}
                    className="w-full cursor-pointer accent-yellow-400" />
                </div>
                {/* Volume */}
                <div className="p-3">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-gray-500 text-[10px] uppercase tracking-widest font-black">Ses Seviyesi</p>
                    <span className="text-white text-xs font-black">{isMuted ? 0 : volume}%</span>
                  </div>
                  <input type="range" min="0" max="100" value={isMuted ? 0 : volume}
                    onChange={e => { setVolume(Number(e.target.value)); setIsMuted(false); }}
                    className="w-full cursor-pointer accent-red-500" />
                </div>
              </div>
            </div>
          )}

          {/* ── Subtitle Panel ── */}
          {showSubtitlePanel && (
            <div className="absolute right-4 bottom-24 w-52 bg-[#0f0f0f]/98 backdrop-blur-2xl rounded-2xl border border-white/10 overflow-hidden z-30 shadow-2xl pointer-events-auto">
              <div className="flex items-center justify-between px-4 py-3 border-b border-white/8">
                <h3 className="text-white font-black text-sm flex items-center gap-2">
                  <Subtitles size={14} className="text-red-400" /> Altyazı
                </h3>
                <button onClick={() => setShowSubtitlePanel(false)} className="w-6 h-6 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/15">
                  <X size={13} className="text-gray-400" />
                </button>
              </div>
              <div className="p-1.5 max-h-60 overflow-y-auto">
                {subtitleOptions.map(opt => (
                  <button key={opt} onClick={() => { setSelectedSubtitle(opt); setShowSubtitlePanel(false); }}
                    className={`w-full text-left px-3 py-2.5 rounded-xl text-sm flex items-center justify-between transition-colors ${selectedSubtitle === opt ? 'bg-red-600/20 text-red-400 font-bold' : 'text-gray-300 hover:bg-white/5'}`}>
                    {opt} {selectedSubtitle === opt && <Check size={13} className="text-red-400" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ── Audio Panel ── */}
          {showAudioPanel && (
            <div className="absolute right-28 bottom-24 w-52 bg-[#0f0f0f]/98 backdrop-blur-2xl rounded-2xl border border-white/10 overflow-hidden z-30 shadow-2xl pointer-events-auto">
              <div className="flex items-center justify-between px-4 py-3 border-b border-white/8">
                <h3 className="text-white font-black text-sm flex items-center gap-2">
                  <Languages size={14} className="text-blue-400" /> Ses Dili
                </h3>
                <button onClick={() => setShowAudioPanel(false)} className="w-6 h-6 rounded-lg bg-white/5 flex items-center justify-center hover:bg-white/15">
                  <X size={13} className="text-gray-400" />
                </button>
              </div>
              <div className="p-1.5 max-h-60 overflow-y-auto">
                {audioOptions.map(opt => (
                  <button key={opt} onClick={() => { setSelectedAudio(opt); setShowAudioPanel(false); }}
                    className={`w-full text-left px-3 py-2.5 rounded-xl text-sm flex items-center justify-between transition-colors ${selectedAudio === opt ? 'bg-blue-600/20 text-blue-400 font-bold' : 'text-gray-300 hover:bg-white/5'}`}>
                    {opt} {selectedAudio === opt && <Check size={13} className="text-blue-400" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Mini bar when controls are hidden ── */}
      {!showControls && channel.isLive && !hasError && (
        <div className="absolute top-4 left-4 z-10 bg-black/60 backdrop-blur border border-white/10 rounded-xl px-3 py-2 flex items-center gap-2 pointer-events-none">
          <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          <span className="text-white text-sm font-bold">{channel.name}</span>
          <span className="text-red-400 text-xs font-black">CANLI</span>
        </div>
      )}
    </div>
  );
};

// Inline Subtitles icon (lucide doesn't export this)
const Subtitles = ({ size, className }: { size: number; className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="2" y="6" width="20" height="12" rx="2" />
    <path d="M7 12h4M7 16h10M15 12h2" />
  </svg>
);

export default VideoPlayer;
