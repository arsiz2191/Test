import React, { useState } from 'react';
import { Tv, Radio, FileText, Eye, EyeOff, Globe, Server, Link, ArrowRight, Shield, Zap, Star } from 'lucide-react';

interface Props {
  onLogin: (type: 'xstream' | 'm3u') => void;
}

const LoginScreen: React.FC<Props> = ({ onLogin }) => {
  const [activeTab, setActiveTab] = useState<'select' | 'xstream' | 'm3u'>('select');
  const [showPassword, setShowPassword] = useState(false);
  const [xstreamForm, setXstreamForm] = useState({ server: '', username: '', password: '', port: '' });
  const [m3uForm, setM3uForm] = useState({ url: '', name: '' });
  const [isLoading, setIsLoading] = useState(false);

  const handleXstreamLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin('xstream');
    }, 1500);
  };

  const handleM3uLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin('m3u');
    }, 1500);
  };

  if (activeTab === 'select') {
    return (
      <div className="min-h-screen bg-inci-darker relative overflow-hidden">
        <div className="absolute inset-0">
          <img src="https://picsum.photos/seed/iptv-bg/1920/1080" alt="" className="w-full h-full object-cover opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black" />
        </div>

        <div className="relative z-10 min-h-screen flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-center pt-12 pb-6">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 bg-gradient-to-br from-inci-red to-inci-purple rounded-xl flex items-center justify-center">
                <Tv size={28} className="text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-black text-white">İNCİ <span className="text-inci-red">İPTV</span> PRO</h1>
                <p className="text-xs text-gray-400 tracking-widest uppercase">Premium Streaming</p>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className="flex justify-center gap-8 mb-12 px-4">
            {[
              { icon: Shield, text: 'Güvenli Bağlantı' },
              { icon: Zap, text: 'Hızlı Yükleme' },
              { icon: Star, text: '4K Kalite' },
            ].map((f, i) => (
              <div key={i} className="flex items-center gap-2 text-gray-400">
                <f.icon size={16} className="text-inci-red" />
                <span className="text-sm">{f.text}</span>
              </div>
            ))}
          </div>

          {/* Login Options */}
          <div className="flex-1 flex items-start justify-center px-4">
            <div className="w-full max-w-lg space-y-5">
              <h2 className="text-2xl font-bold text-white text-center mb-8">Giriş Yöntemini Seçin</h2>

              {/* Xstream Option */}
              <button
                onClick={() => setActiveTab('xstream')}
                className="w-full group relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-6 text-left transition-all duration-300 hover:border-inci-red/50 hover:bg-white/10"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-inci-red/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative flex items-center gap-5">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-inci-red to-inci-red-dark flex items-center justify-center flex-shrink-0">
                    <Server size={28} className="text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-white mb-1">Xstream Codes Giriş</h3>
                    <p className="text-gray-400 text-sm">Sunucu adresi, kullanıcı adı ve şifre ile giriş yapın. Xtream Codes API desteği.</p>
                  </div>
                  <ArrowRight size={24} className="text-gray-500 group-hover:text-inci-red transition-colors flex-shrink-0" />
                </div>
                <div className="relative mt-4 flex gap-2">
                  {['API Desteği', 'EPG Rehberi', 'VOD', 'Canlı TV'].map(tag => (
                    <span key={tag} className="px-2 py-1 bg-white/5 rounded-lg text-xs text-gray-400">{tag}</span>
                  ))}
                </div>
              </button>

              {/* M3U Option */}
              <button
                onClick={() => setActiveTab('m3u')}
                className="w-full group relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-6 text-left transition-all duration-300 hover:border-inci-blue/50 hover:bg-white/10"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-inci-blue/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative flex items-center gap-5">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-inci-blue to-blue-800 flex items-center justify-center flex-shrink-0">
                    <FileText size={28} className="text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-white mb-1">M3U / M3U8 Giriş</h3>
                    <p className="text-gray-400 text-sm">M3U playlist URL'si veya dosyası ile giriş yapın. Tüm formatlar desteklenir.</p>
                  </div>
                  <ArrowRight size={24} className="text-gray-500 group-hover:text-inci-blue transition-colors flex-shrink-0" />
                </div>
                <div className="relative mt-4 flex gap-2">
                  {['M3U', 'M3U8', 'URL', 'Dosya'].map(tag => (
                    <span key={tag} className="px-2 py-1 bg-white/5 rounded-lg text-xs text-gray-400">{tag}</span>
                  ))}
                </div>
              </button>

              <p className="text-center text-gray-600 text-xs mt-8">
                İNCİ İPTV PRO v3.0 • Tüm hakları saklıdır © 2024
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (activeTab === 'xstream') {
    return (
      <div className="min-h-screen bg-inci-darker relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-inci-red/5 to-transparent" />
        </div>
        <div className="relative z-10 min-h-screen flex flex-col">
          <div className="flex items-center gap-4 p-6">
            <button onClick={() => setActiveTab('select')} className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
              <ArrowRight size={20} className="text-white rotate-180" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white">Xstream Codes Giriş</h1>
              <p className="text-gray-400 text-sm">Sunucu bilgilerinizi girin</p>
            </div>
          </div>

          <div className="flex-1 flex items-start justify-center px-4 pt-4">
            <form onSubmit={handleXstreamLogin} className="w-full max-w-md space-y-5">
              <div className="glass-effect rounded-2xl p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    <Globe size={14} className="inline mr-2" />Sunucu Adresi (URL)
                  </label>
                  <input
                    type="text"
                    placeholder="http://example.com"
                    value={xstreamForm.server}
                    onChange={e => setXstreamForm({ ...xstreamForm, server: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-500 focus:border-inci-red focus:outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    <Link size={14} className="inline mr-2" />Port
                  </label>
                  <input
                    type="text"
                    placeholder="8080"
                    value={xstreamForm.port}
                    onChange={e => setXstreamForm({ ...xstreamForm, port: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-500 focus:border-inci-red focus:outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    <Radio size={14} className="inline mr-2" />Kullanıcı Adı
                  </label>
                  <input
                    type="text"
                    placeholder="username"
                    value={xstreamForm.username}
                    onChange={e => setXstreamForm({ ...xstreamForm, username: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-500 focus:border-inci-red focus:outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    <Shield size={14} className="inline mr-2" />Şifre
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={xstreamForm.password}
                      onChange={e => setXstreamForm({ ...xstreamForm, password: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-500 focus:border-inci-red focus:outline-none transition-colors pr-12"
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-4 bg-gradient-to-r from-inci-red to-inci-red-dark rounded-xl font-bold text-white text-lg hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Bağlanıyor...
                  </>
                ) : (
                  <>
                    <Server size={20} />
                    Giriş Yap
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-inci-darker relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-inci-blue/5 to-transparent" />
      </div>
      <div className="relative z-10 min-h-screen flex flex-col">
        <div className="flex items-center gap-4 p-6">
          <button onClick={() => setActiveTab('select')} className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
            <ArrowRight size={20} className="text-white rotate-180" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-white">M3U / M3U8 Giriş</h1>
            <p className="text-gray-400 text-sm">Playlist URL'nizi girin</p>
          </div>
        </div>

        <div className="flex-1 flex items-start justify-center px-4 pt-4">
          <form onSubmit={handleM3uLogin} className="w-full max-w-md space-y-5">
            <div className="glass-effect rounded-2xl p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  <FileText size={14} className="inline mr-2" />Playlist Adı
                </label>
                <input
                  type="text"
                  placeholder="Playlist adı girin"
                  value={m3uForm.name}
                  onChange={e => setM3uForm({ ...m3uForm, name: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-500 focus:border-inci-blue focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  <Link size={14} className="inline mr-2" />M3U URL
                </label>
                <textarea
                  placeholder="http://example.com/playlist.m3u8"
                  rows={3}
                  value={m3uForm.url}
                  onChange={e => setM3uForm({ ...m3uForm, url: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-500 focus:border-inci-blue focus:outline-none transition-colors resize-none"
                />
              </div>

              <div className="bg-white/5 rounded-xl p-4">
                <p className="text-xs text-gray-400 leading-relaxed">
                  <span className="text-inci-blue font-medium">Desteklenen formatlar:</span> M3U, M3U8, TS, MP4, MKV, AVI, FLV, MOV, WEBM, HLS, MPEG-DASH
                </p>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-4 bg-gradient-to-r from-inci-blue to-blue-800 rounded-xl font-bold text-white text-lg hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Yükleniyor...
                </>
              ) : (
                <>
                  <FileText size={20} />
                  Playlist Yükle
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;
