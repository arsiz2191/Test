import React, { useState, useRef, useEffect } from 'react';
import {
  Tv, Search, Heart, Settings, LogOut, Play, Star, ChevronLeft, ChevronRight,
  Radio, Film, Clapperboard, Trophy, Globe2, Baby, Music, Newspaper, Menu, X,
  Info, Plus, Check, TrendingUp, Sparkles, Flame, Clock, Bell
} from 'lucide-react';
import { Channel } from '../types';
import { categories, featuredMovies, featuredSeries, featuredLive, searchChannels, getAllChannels } from '../data';

interface Props {
  onPlayChannel: (channel: Channel) => void;
  onLogout: () => void;
}

type MainTab = 'movies' | 'series' | 'live';
type SubTab = 'home' | 'search' | 'favorites' | 'settings';

const HomeScreen: React.FC<Props> = ({ onPlayChannel, onLogout }) => {
  const [mainTab, setMainTab] = useState<MainTab>('movies');
  const [subTab, setSubTab] = useState<SubTab>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [myList, setMyList] = useState<string[]>([]);
  const [featuredIndex, setFeaturedIndex] = useState(0);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const getFeaturedList = () => {
    if (mainTab === 'movies') return featuredMovies;
    if (mainTab === 'series') return featuredSeries;
    return featuredLive;
  };

  useEffect(() => {
    setFeaturedIndex(0);
  }, [mainTab]);

  useEffect(() => {
    const list = getFeaturedList();
    const interval = setInterval(() => {
      setFeaturedIndex(prev => (prev + 1) % list.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [mainTab]);

  const toggleFavorite = (id: string) => {
    setFavorites(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);
  };

  const toggleMyList = (id: string) => {
    setMyList(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);
  };

  const featuredList = getFeaturedList();
  const featured = featuredList[featuredIndex] || featuredList[0];

  // ---- Content Row Component ----
  const ContentRow: React.FC<{ title: string; channels: Channel[]; icon?: React.ReactNode; badge?: string }> = ({ title, channels, icon, badge }) => {
    const scrollRef = useRef<HTMLDivElement>(null);
    const scroll = (dir: number) => scrollRef.current?.scrollBy({ left: dir * 320, behavior: 'smooth' });
    if (channels.length === 0) return null;
    return (
      <div className="mb-10">
        <div className="flex items-center justify-between px-4 sm:px-10 mb-3">
          <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
            {icon}{title}
            {badge && <span className="text-[10px] bg-red-600 text-white px-1.5 py-0.5 rounded font-bold">{badge}</span>}
          </h3>
          <div className="flex gap-1">
            <button onClick={() => scroll(-1)} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
              <ChevronLeft size={15} className="text-white" />
            </button>
            <button onClick={() => scroll(1)} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
              <ChevronRight size={15} className="text-white" />
            </button>
          </div>
        </div>
        <div ref={scrollRef} className="flex gap-3 px-4 sm:px-10 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
          {channels.map(channel => (
            <ContentCard key={channel.id} channel={channel} />
          ))}
        </div>
      </div>
    );
  };

  // ---- Content Card ----
  const ContentCard: React.FC<{ channel: Channel; wide?: boolean }> = ({ channel, wide }) => (
    <div
      className="flex-shrink-0 group cursor-pointer"
      style={{ width: wide ? 260 : (mainTab === 'live' ? 180 : 150) }}
      onClick={() => setSelectedChannel(channel)}
    >
      <div className={`relative rounded-xl overflow-hidden mb-2 ${wide ? 'aspect-video' : mainTab === 'live' ? 'aspect-video' : 'aspect-[2/3]'} bg-gray-900`}>
        <img
          src={channel.logo}
          alt={channel.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-300" />

        {/* Hover play button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
          <div className="w-14 h-14 rounded-full bg-red-600/90 backdrop-blur flex items-center justify-center shadow-2xl transform scale-75 group-hover:scale-100 transition-transform duration-300">
            <Play size={26} className="text-white ml-1" />
          </div>
        </div>

        {/* Badges */}
        {channel.isLive && (
          <div className="absolute top-2 left-2 bg-red-600 text-white text-[9px] font-black px-2 py-0.5 rounded flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> CANLI
          </div>
        )}
        {channel.quality && !channel.isLive && (
          <div className="absolute top-2 right-2 bg-black/80 text-yellow-400 text-[9px] font-black px-1.5 py-0.5 rounded border border-yellow-400/30">
            {channel.quality}
          </div>
        )}

        {/* Bottom info on hover */}
        <div className="absolute bottom-0 left-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="flex gap-1.5">
            <button
              onClick={e => { e.stopPropagation(); toggleFavorite(channel.id); }}
              className="w-7 h-7 rounded-full bg-white/20 backdrop-blur flex items-center justify-center hover:bg-white/40 transition-colors"
            >
              <Heart size={12} className={favorites.includes(channel.id) ? 'text-red-500 fill-red-500' : 'text-white'} />
            </button>
            <button
              onClick={e => { e.stopPropagation(); toggleMyList(channel.id); }}
              className="w-7 h-7 rounded-full bg-white/20 backdrop-blur flex items-center justify-center hover:bg-white/40 transition-colors"
            >
              {myList.includes(channel.id) ? <Check size={12} className="text-green-400" /> : <Plus size={12} className="text-white" />}
            </button>
          </div>
        </div>
      </div>
      <h4 className="text-xs sm:text-sm text-white font-semibold truncate leading-snug">{channel.name}</h4>
      <div className="flex items-center gap-1.5 mt-0.5">
        {channel.rating && (
          <span className="flex items-center gap-0.5 text-[11px] text-yellow-400 font-bold">
            <Star size={9} className="fill-yellow-400" /> {channel.rating}
          </span>
        )}
        {channel.year && <span className="text-[11px] text-gray-500">• {channel.year}</span>}
        {channel.duration && !channel.isLive && <span className="text-[11px] text-gray-500">• {channel.duration}</span>}
      </div>
    </div>
  );

  // ---- Grid View ----
  const GridView: React.FC<{ channels: Channel[] }> = ({ channels }) => (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4 px-4 sm:px-10 pb-24">
      {channels.map(channel => (
        <div key={channel.id} className="group cursor-pointer" onClick={() => setSelectedChannel(channel)}>
          <div className={`relative rounded-xl overflow-hidden bg-gray-900 ${mainTab === 'live' ? 'aspect-video' : 'aspect-[2/3]'} mb-2`}>
            <img src={channel.logo} alt={channel.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
              <div className="w-14 h-14 rounded-full bg-red-600/90 backdrop-blur flex items-center justify-center">
                <Play size={26} className="text-white ml-1" />
              </div>
            </div>
            {channel.isLive && (
              <div className="absolute top-2 left-2 bg-red-600 text-white text-[9px] font-black px-2 py-0.5 rounded flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> CANLI
              </div>
            )}
            {channel.quality && (
              <div className="absolute top-2 right-2 bg-black/80 text-yellow-400 text-[9px] font-black px-1.5 py-0.5 rounded">
                {channel.quality}
              </div>
            )}
          </div>
          <h4 className="text-sm text-white font-semibold truncate">{channel.name}</h4>
          <div className="flex items-center gap-1 mt-0.5">
            {channel.rating && <span className="flex items-center gap-0.5 text-[11px] text-yellow-400"><Star size={9} className="fill-yellow-400" /> {channel.rating}</span>}
            {channel.year && <span className="text-[11px] text-gray-500">• {channel.year}</span>}
          </div>
        </div>
      ))}
    </div>
  );

  // ---- Live TV Channel Row (horizontal landscape cards) ----
  const LiveRow: React.FC<{ title: string; channels: Channel[]; icon?: React.ReactNode }> = ({ title, channels, icon }) => {
    const scrollRef = useRef<HTMLDivElement>(null);
    const scroll = (dir: number) => scrollRef.current?.scrollBy({ left: dir * 400, behavior: 'smooth' });
    if (channels.length === 0) return null;
    return (
      <div className="mb-10">
        <div className="flex items-center justify-between px-4 sm:px-10 mb-3">
          <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">{icon}{title}</h3>
          <div className="flex gap-1">
            <button onClick={() => scroll(-1)} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20"><ChevronLeft size={15} className="text-white" /></button>
            <button onClick={() => scroll(1)} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20"><ChevronRight size={15} className="text-white" /></button>
          </div>
        </div>
        <div ref={scrollRef} className="flex gap-3 px-4 sm:px-10 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none' }}>
          {channels.map(channel => (
            <div key={channel.id} className="flex-shrink-0 w-52 sm:w-64 group cursor-pointer" onClick={() => setSelectedChannel(channel)}>
              <div className="relative rounded-xl overflow-hidden aspect-video bg-gray-900 mb-2">
                <img src={channel.logo} alt={channel.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                  <div className="w-12 h-12 rounded-full bg-red-600/90 flex items-center justify-center"><Play size={22} className="text-white ml-1" /></div>
                </div>
                <div className="absolute top-2 left-2 bg-red-600 text-white text-[9px] font-black px-2 py-0.5 rounded flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> CANLI
                </div>
                {channel.quality && (
                  <div className="absolute top-2 right-2 bg-black/80 text-yellow-400 text-[9px] font-black px-1.5 py-0.5 rounded">{channel.quality}</div>
                )}
              </div>
              <h4 className="text-sm text-white font-semibold truncate">{channel.name}</h4>
              <p className="text-[11px] text-gray-400 truncate">{channel.description}</p>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const isHomeActive = subTab === 'home';

  // ---- Movies Page ----
  const MoviesPage = () => (
    <>
      {/* Hero Banner */}
      {featured && isHomeActive && (
        <HeroBanner featured={featured} />
      )}
      {isHomeActive ? (
        <div className="pb-4">
          <ContentRow title="Popüler Filmler" icon={<Flame size={18} className="text-orange-400" />} badge="HOT" channels={categories.find(c => c.id === 'movies')?.channels.slice(0, 12) || []} />
          <ContentRow title="Yeni Çıkanlar" icon={<Sparkles size={18} className="text-yellow-400" />} channels={categories.find(c => c.id === 'movies')?.channels.slice(5, 18) || []} />
          <ContentRow title="Aksiyon & Macera" icon={<TrendingUp size={18} className="text-red-400" />} channels={categories.find(c => c.id === 'movies')?.channels.slice(0, 10) || []} />
          <ContentRow title="Belgesel" icon={<Globe2 size={18} className="text-blue-400" />} channels={categories.find(c => c.id === 'documentary')?.channels || []} />
          <ContentRow title="Çocuk & Aile" icon={<Baby size={18} className="text-pink-400" />} channels={categories.find(c => c.id === 'kids')?.channels || []} />
          <div className="pb-20" />
        </div>
      ) : null}
    </>
  );

  // ---- Series Page ----
  const SeriesPage = () => (
    <>
      {featured && isHomeActive && <HeroBanner featured={featured} />}
      {isHomeActive ? (
        <div className="pb-4">
          <ContentRow title="Trend Diziler" icon={<TrendingUp size={18} className="text-red-400" />} badge="TREND" channels={categories.find(c => c.id === 'series')?.channels.slice(0, 12) || []} />
          <ContentRow title="Yeni Bölümler" icon={<Bell size={18} className="text-blue-400" />} channels={categories.find(c => c.id === 'series')?.channels.slice(3, 15) || []} />
          <ContentRow title="Yerli Diziler" icon={<Sparkles size={18} className="text-yellow-400" />} channels={categories.find(c => c.id === 'series')?.channels.slice(10, 20) || []} />
          <ContentRow title="Dizi Önerileri" icon={<Star size={18} className="text-yellow-400" />} channels={categories.find(c => c.id === 'series')?.channels || []} />
          <div className="pb-20" />
        </div>
      ) : null}
    </>
  );

  // ---- Live TV Page ----
  const LivePage = () => (
    <>
      {featured && isHomeActive && <HeroBanner featured={featured} live />}
      {isHomeActive ? (
        <div className="pb-4">
          <LiveRow title="Genel Kanallar" icon={<Tv size={18} className="text-white" />} channels={categories.find(c => c.id === 'live')?.channels || []} />
          <LiveRow title="Spor Kanalları" icon={<Trophy size={18} className="text-green-400" />} channels={categories.find(c => c.id === 'sports')?.channels || []} />
          <LiveRow title="Haber Kanalları" icon={<Newspaper size={18} className="text-blue-400" />} channels={categories.find(c => c.id === 'news')?.channels || []} />
          <LiveRow title="Müzik Kanalları" icon={<Music size={18} className="text-purple-400" />} channels={categories.find(c => c.id === 'music')?.channels || []} />
          <div className="pb-20" />
        </div>
      ) : null}
    </>
  );

  // ---- Hero Banner ----
  const HeroBanner: React.FC<{ featured: Channel; live?: boolean }> = ({ featured, live }) => (
    <div className="relative h-[62vh] sm:h-[75vh] mb-6 overflow-hidden">
      <img
        key={featured.id}
        src={featured.backdrop || featured.logo}
        alt={featured.name}
        className="absolute inset-0 w-full h-full object-cover transition-all duration-1000"
      />
      {/* Vignette layers */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/20 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#0f0f0f]/80 via-transparent to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0f0f0f]/30 to-transparent" />

      <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-10 pb-8 sm:pb-12">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <span className="bg-red-600 px-2.5 py-0.5 rounded text-xs font-black text-white tracking-wide">
              {live ? 'CANLI' : 'İNCİ ORİJİNAL'}
            </span>
            {live && <span className="flex items-center gap-1 text-red-400 text-xs font-bold"><span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />YAYIN</span>}
            <span className="text-yellow-400 text-xs font-black">{featured.quality}</span>
            {featured.rating && <span className="flex items-center gap-1 text-yellow-400 text-xs font-bold"><Star size={11} className="fill-yellow-400" />{featured.rating}</span>}
          </div>
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-black text-white mb-3 leading-tight drop-shadow-2xl">
            {featured.name}
          </h1>
          <div className="flex items-center gap-3 mb-4 text-xs sm:text-sm text-gray-300 flex-wrap">
            {featured.rating && (
              <span className="flex items-center gap-1 text-green-400 font-black">%{Math.round((featured.rating) * 10)} Eşleşme</span>
            )}
            {featured.year && <span>{featured.year}</span>}
            {featured.duration && <span className="border border-gray-500 px-1.5 py-0.5 text-[10px]">{featured.duration}</span>}
          </div>
          <p className="text-gray-300 text-sm sm:text-base leading-relaxed mb-5 line-clamp-2 sm:line-clamp-3">
            {featured.description}
          </p>
          <div className="flex gap-3">
            <button
              onClick={() => onPlayChannel(featured)}
              className="flex items-center gap-2 bg-white hover:bg-gray-200 text-black font-black px-6 sm:px-8 py-2.5 sm:py-3 rounded-lg transition-all hover:scale-105 active:scale-95 shadow-2xl"
            >
              <Play size={20} className="fill-black" /> Oynat
            </button>
            <button
              onClick={() => setSelectedChannel(featured)}
              className="flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white font-bold px-6 sm:px-8 py-2.5 sm:py-3 rounded-lg backdrop-blur transition-all hover:scale-105 active:scale-95"
            >
              <Info size={18} /> Bilgi
            </button>
          </div>
        </div>
      </div>

      {/* Featured dots */}
      <div className="absolute bottom-6 right-5 sm:right-10 flex gap-1.5">
        {featuredList.map((_, i) => (
          <button
            key={i}
            onClick={() => setFeaturedIndex(i)}
            className={`h-1 rounded-full transition-all duration-300 ${i === featuredIndex ? 'w-8 bg-red-500' : 'w-3 bg-white/30 hover:bg-white/50'}`}
          />
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white">

      {/* Mobile Sidebar */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-72 bg-[#141414] border-r border-white/5 p-6 flex flex-col">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 bg-gradient-to-br from-red-600 to-red-800 rounded-lg flex items-center justify-center">
                  <Tv size={18} className="text-white" />
                </div>
                <div>
                  <span className="text-base font-black text-white">İNCİ <span className="text-red-500">İPTV</span></span>
                  <span className="block text-[10px] text-gray-500 font-medium tracking-widest">PRO</span>
                </div>
              </div>
              <button onClick={() => setSidebarOpen(false)}>
                <X size={22} className="text-gray-400 hover:text-white" />
              </button>
            </div>
            <nav className="space-y-1 flex-1">
              {[
                { tab: 'movies' as MainTab, label: 'Filmler', icon: <Film size={18} /> },
                { tab: 'series' as MainTab, label: 'Diziler', icon: <Clapperboard size={18} /> },
                { tab: 'live' as MainTab, label: 'Canlı TV', icon: <Radio size={18} /> },
              ].map(item => (
                <button key={item.tab} onClick={() => { setMainTab(item.tab); setSubTab('home'); setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-colors ${mainTab === item.tab && subTab === 'home' ? 'bg-red-600/20 text-red-400' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}>
                  {item.icon} {item.label}
                </button>
              ))}
              <div className="border-t border-white/5 my-3" />
              {[
                { tab: 'favorites' as SubTab, label: 'Favorilerim', icon: <Heart size={18} /> },
                { tab: 'search' as SubTab, label: 'Ara', icon: <Search size={18} /> },
                { tab: 'settings' as SubTab, label: 'Ayarlar', icon: <Settings size={18} /> },
              ].map(item => (
                <button key={item.tab} onClick={() => { setSubTab(item.tab); setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-colors ${subTab === item.tab ? 'bg-red-600/20 text-red-400' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}>
                  {item.icon} {item.label}
                </button>
              ))}
            </nav>
            <button onClick={onLogout} className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-gray-400 hover:bg-red-600/10 hover:text-red-400 transition-colors">
              <LogOut size={18} /> Çıkış Yap
            </button>
          </div>
        </div>
      )}

      {/* Channel Detail Modal */}
      {selectedChannel && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm" onClick={() => setSelectedChannel(null)} />
          <div className="relative w-full max-w-2xl bg-[#1a1a1a] rounded-t-3xl sm:rounded-3xl overflow-hidden border border-white/10 max-h-[90vh] overflow-y-auto">
            <div className="relative h-52 sm:h-72">
              <img src={selectedChannel.backdrop || selectedChannel.logo} alt={selectedChannel.name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] via-[#1a1a1a]/30 to-transparent" />
              <button onClick={() => setSelectedChannel(null)} className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/60 flex items-center justify-center hover:bg-black/80">
                <X size={18} className="text-white" />
              </button>
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  {selectedChannel.isLive && (
                    <span className="bg-red-600 text-white text-xs font-black px-2 py-0.5 rounded flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> CANLI
                    </span>
                  )}
                  {selectedChannel.quality && <span className="bg-yellow-400/20 text-yellow-400 text-xs font-black px-2 py-0.5 rounded">{selectedChannel.quality}</span>}
                </div>
                <h2 className="text-2xl sm:text-3xl font-black text-white">{selectedChannel.name}</h2>
              </div>
            </div>
            <div className="p-5">
              <div className="flex items-center gap-3 mb-3 text-sm flex-wrap">
                {selectedChannel.rating && <span className="flex items-center gap-1 text-yellow-400 font-bold"><Star size={14} className="fill-yellow-400" />{selectedChannel.rating}</span>}
                {selectedChannel.year && <span className="text-gray-400">{selectedChannel.year}</span>}
                {selectedChannel.duration && <span className="border border-gray-600 text-gray-400 px-1.5 py-0.5 text-xs rounded">{selectedChannel.duration}</span>}
                <span className="text-gray-500 text-xs">{selectedChannel.category}</span>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-5">{selectedChannel.description}</p>
              <div className="flex gap-3">
                <button
                  onClick={() => { onPlayChannel(selectedChannel); setSelectedChannel(null); }}
                  className="flex-1 flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 py-3.5 rounded-xl font-black text-white transition-colors"
                >
                  <Play size={20} className="fill-white" /> Oynat
                </button>
                <button onClick={() => toggleFavorite(selectedChannel.id)} className="w-14 h-14 rounded-xl bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
                  <Heart size={20} className={favorites.includes(selectedChannel.id) ? 'text-red-500 fill-red-500' : 'text-white'} />
                </button>
                <button onClick={() => toggleMyList(selectedChannel.id)} className="w-14 h-14 rounded-xl bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
                  {myList.includes(selectedChannel.id) ? <Check size={20} className="text-green-400" /> : <Plus size={20} className="text-white" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---- TOP HEADER ---- */}
      <header className="fixed top-0 left-0 right-0 z-40">
        <div className="bg-gradient-to-b from-[#0f0f0f] via-[#0f0f0f]/95 to-transparent">
          <div className="flex items-center justify-between px-4 sm:px-8 py-3">
            {/* Logo + Mobile Menu */}
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden w-9 h-9 rounded-xl bg-white/5 flex items-center justify-center">
                <Menu size={18} className="text-white" />
              </button>
              <div className="flex items-center gap-2 cursor-pointer" onClick={() => { setMainTab('movies'); setSubTab('home'); }}>
                <div className="w-8 h-8 sm:w-9 sm:h-9 bg-gradient-to-br from-red-600 to-red-800 rounded-lg flex items-center justify-center shadow-lg">
                  <Tv size={16} className="text-white" />
                </div>
                <div className="hidden sm:block">
                  <span className="text-sm font-black text-white">İNCİ <span className="text-red-500">İPTV</span></span>
                  <span className="block text-[9px] text-gray-500 font-bold tracking-widest leading-none">PRO</span>
                </div>
              </div>
            </div>

            {/* Desktop: Main 3 Tabs */}
            <nav className="hidden lg:flex items-center gap-1">
              {[
                { tab: 'movies' as MainTab, label: 'Filmler', icon: <Film size={15} /> },
                { tab: 'series' as MainTab, label: 'Diziler', icon: <Clapperboard size={15} /> },
                { tab: 'live' as MainTab, label: 'Canlı TV', icon: <Radio size={15} /> },
              ].map(item => (
                <button
                  key={item.tab}
                  onClick={() => { setMainTab(item.tab); setSubTab('home'); }}
                  className={`flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-bold transition-all ${mainTab === item.tab && subTab === 'home' ? 'bg-red-600 text-white shadow-lg shadow-red-600/30' : 'text-gray-400 hover:text-white hover:bg-white/8'}`}
                >
                  {item.icon} {item.label}
                </button>
              ))}
            </nav>

            {/* Right Actions */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                onClick={() => { setSubTab('search'); setTimeout(() => searchInputRef.current?.focus(), 100); }}
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${subTab === 'search' ? 'bg-red-600' : 'bg-white/5 hover:bg-white/12'}`}
              >
                <Search size={17} className="text-white" />
              </button>
              <button
                onClick={() => setSubTab('favorites')}
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${subTab === 'favorites' ? 'bg-red-600' : 'bg-white/5 hover:bg-white/12'}`}
              >
                <Heart size={17} className={subTab === 'favorites' ? 'text-white fill-white' : 'text-gray-300'} />
              </button>
              <button
                onClick={onLogout}
                className="hidden sm:flex w-9 h-9 rounded-xl bg-white/5 items-center justify-center hover:bg-white/12 transition-colors"
              >
                <LogOut size={17} className="text-gray-300" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* ---- MAIN CONTENT ---- */}
      <main className="pt-14">

        {/* Search */}
        {subTab === 'search' && (
          <div className="px-4 sm:px-10 pt-6 pb-24">
            <div className="max-w-2xl mx-auto mb-8">
              <div className="relative">
                <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder="Film, dizi, kanal, oyuncu..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-10 py-4 text-white placeholder-gray-500 focus:border-red-600 focus:outline-none text-base"
                  autoFocus
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2">
                    <X size={18} className="text-gray-400 hover:text-white" />
                  </button>
                )}
              </div>
            </div>
            {searchQuery ? (
              <GridView channels={searchChannels(searchQuery)} />
            ) : (
              <div className="text-center py-24">
                <Search size={52} className="text-gray-700 mx-auto mb-4" />
                <p className="text-gray-400 text-lg font-semibold">Ne aramak istersiniz?</p>
                <p className="text-gray-600 text-sm mt-1">Film, dizi veya kanal adı yazın</p>
              </div>
            )}
          </div>
        )}

        {/* Favorites */}
        {subTab === 'favorites' && (
          <div className="px-4 sm:px-10 pt-6 pb-24">
            <h2 className="text-2xl font-black text-white mb-6 flex items-center gap-2">
              <Heart size={22} className="text-red-500 fill-red-500" /> Favorilerim
            </h2>
            {favorites.length === 0 ? (
              <div className="text-center py-24">
                <Heart size={52} className="text-gray-700 mx-auto mb-4" />
                <p className="text-gray-400 text-lg font-semibold">Favori listeniz boş</p>
                <p className="text-gray-600 text-sm mt-1">İçeriklerin üzerine gelip ♥ ikonuna tıklayın</p>
              </div>
            ) : (
              <GridView channels={getAllChannels().filter(c => favorites.includes(c.id))} />
            )}
          </div>
        )}

        {/* Settings */}
        {subTab === 'settings' && (
          <div className="px-4 sm:px-10 pt-6 pb-24 max-w-2xl mx-auto">
            <h2 className="text-2xl font-black text-white mb-6 flex items-center gap-2">
              <Settings size={22} /> Ayarlar
            </h2>
            <div className="space-y-3">
              {[
                { title: 'Uygulama Sürümü', desc: 'İNCİ İPTV PRO v3.0.0', icon: <Tv size={20} className="text-red-400" /> },
                { title: 'Video Kalitesi', desc: 'Otomatik (En İyi Kalite)', icon: <Film size={20} className="text-blue-400" /> },
                { title: 'Altyazı Varsayılan', desc: 'Türkçe', icon: <Subtitles size={20} className="text-green-400" /> },
                { title: 'Ses Dili', desc: 'Türkçe', icon: <Music size={20} className="text-purple-400" /> },
                { title: 'İzleme Geçmişi', desc: 'Son 50 içerik', icon: <Clock size={20} className="text-yellow-400" /> },
                { title: 'Bildirimler', desc: 'Yeni içerikler için açık', icon: <Bell size={20} className="text-orange-400" /> },
              ].map((item: { title: string; desc: string; icon: React.ReactNode }, i: number) => (
                <div key={i} className="bg-white/5 rounded-xl p-4 flex items-center gap-4 hover:bg-white/8 cursor-pointer transition-colors border border-white/5">
                  <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">{item.icon}</div>
                  <div className="flex-1">
                    <p className="text-white font-semibold text-sm">{item.title}</p>
                    <p className="text-gray-500 text-xs">{item.desc}</p>
                  </div>
                  <ChevronRight size={16} className="text-gray-600" />
                </div>
              ))}
              <button onClick={onLogout} className="w-full mt-4 py-4 bg-red-600/10 border border-red-600/30 rounded-xl text-red-400 font-black hover:bg-red-600/20 transition-colors flex items-center justify-center gap-2">
                <LogOut size={18} /> Çıkış Yap
              </button>
            </div>
          </div>
        )}

        {/* Home content - tab based */}
        {subTab === 'home' && mainTab === 'movies' && <MoviesPage />}
        {subTab === 'home' && mainTab === 'series' && <SeriesPage />}
        {subTab === 'home' && mainTab === 'live' && <LivePage />}
      </main>

      {/* ---- BOTTOM TAB BAR (Mobile) ---- */}
      <div className="fixed bottom-0 left-0 right-0 z-40 lg:hidden">
        <div className="bg-[#141414]/95 backdrop-blur-xl border-t border-white/8">
          <div className="flex items-center justify-around py-2 px-2">
            {[
              { tab: 'movies' as MainTab, label: 'Filmler', icon: <Film size={20} />, isMain: true },
              { tab: 'series' as MainTab, label: 'Diziler', icon: <Clapperboard size={20} />, isMain: true },
              { tab: 'live' as MainTab, label: 'Canlı TV', icon: <Radio size={20} />, isMain: true },
              { tab: 'search' as SubTab, label: 'Ara', icon: <Search size={20} />, isMain: false },
              { tab: 'settings' as SubTab, label: 'Menü', icon: <Menu size={20} />, isMain: false },
            ].map(item => {
              const isActive = item.isMain
                ? mainTab === item.tab && subTab === 'home'
                : subTab === item.tab;
              return (
                <button
                  key={item.tab}
                  onClick={() => {
                    if (item.isMain) { setMainTab(item.tab as MainTab); setSubTab('home'); }
                    else if (item.tab === 'settings') { setSidebarOpen(true); }
                    else { setSubTab(item.tab as SubTab); }
                  }}
                  className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all ${isActive ? 'text-red-500' : 'text-gray-500'}`}
                >
                  <div className={`transition-transform ${isActive ? 'scale-110' : 'scale-100'}`}>{item.icon}</div>
                  <span className="text-[9px] font-bold">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

// Needed for inline component usage
const Subtitles = ({ size, className }: { size: number; className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="2" y="6" width="20" height="12" rx="2" />
    <path d="M7 12h4m-4 4h10M15 12h2" />
  </svg>
);

export default HomeScreen;
