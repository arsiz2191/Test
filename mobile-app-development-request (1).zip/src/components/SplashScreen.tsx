import React, { useEffect } from 'react';
import { Tv } from 'lucide-react';

interface Props {
  onFinish: () => void;
}

const SplashScreen: React.FC<Props> = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(onFinish, 2500);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-10"
            style={{
              width: Math.random() * 300 + 50,
              height: Math.random() * 300 + 50,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              background: `radial-gradient(circle, ${i % 2 === 0 ? '#e50914' : '#7b2ff7'}, transparent)`,
              animation: `pulse ${2 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}
      </div>
      <div className="text-center animate-fadeIn relative z-10">
        <div className="flex items-center justify-center mb-6">
          <div className="relative">
            <div className="w-24 h-24 bg-gradient-to-br from-inci-red to-inci-purple rounded-2xl flex items-center justify-center animate-pulse-glow">
              <Tv size={48} className="text-white" />
            </div>
            <div className="absolute -top-1 -right-1 w-6 h-6 bg-inci-green rounded-full flex items-center justify-center">
              <span className="text-xs font-bold text-black">4K</span>
            </div>
          </div>
        </div>
        <h1 className="text-5xl font-black text-white mb-2 tracking-tight">
          İNCİ <span className="text-inci-red">İPTV</span> PRO
        </h1>
        <p className="text-gray-400 text-lg font-light tracking-widest uppercase">Premium Streaming Experience</p>
        <div className="mt-8 flex justify-center">
          <div className="flex gap-1.5">
            {[0, 1, 2].map(i => (
              <div
                key={i}
                className="w-3 h-3 rounded-full bg-inci-red"
                style={{
                  animation: 'pulse 1.4s ease-in-out infinite',
                  animationDelay: `${i * 0.2}s`,
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;
