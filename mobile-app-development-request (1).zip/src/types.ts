export interface Channel {
  id: string;
  name: string;
  logo: string;
  category: string;
  url: string;
  description?: string;
  rating?: number;
  year?: string;
  duration?: string;
  quality?: string;
  isLive?: boolean;
  isFavorite?: boolean;
  backdrop?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  channels: Channel[];
}

export type Screen = 'splash' | 'login' | 'xstream' | 'm3u' | 'home' | 'player' | 'live' | 'movies' | 'series' | 'settings' | 'favorites' | 'search' | 'category';

export interface PlayerState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  brightness: number;
  playbackRate: number;
  aspectRatio: string;
  showControls: boolean;
  showSettings: boolean;
  selectedSubtitle: string;
  selectedAudio: string;
  isFullscreen: boolean;
  isMuted: boolean;
}

export interface AppState {
  currentScreen: Screen;
  selectedChannel: Channel | null;
  selectedCategory: string;
  isLoggedIn: boolean;
  loginType: 'xstream' | 'm3u' | null;
  favorites: string[];
  searchQuery: string;
  sidebarOpen: boolean;
}
