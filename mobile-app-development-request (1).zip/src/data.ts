import { Channel, Category } from './types';

const movieNames = ['Esaretin Bedeli', 'Baba', 'Kara Şövalye', 'Dövüş Kulübü', 'Forrest Gump', 'Yüzüklerin Efendisi', 'Matrix', 'Yıldızlararası', 'Başlangıç', 'Parazit', 'Gladyatör', 'Titanik', 'Avatar', 'Joker', 'Oppenheimer', 'Dune', 'Top Gun: Maverick', 'Spider-Man', 'Batman', 'John Wick 4'];
const seriesNames = ['Breaking Bad', 'Game of Thrones', 'Stranger Things', 'The Witcher', 'Money Heist', 'Dark', 'Peaky Blinders', 'Vikings', 'The Mandalorian', 'Loki', 'Squid Game', 'Wednesday', 'The Last of Us', 'House of Dragon', 'Yellowstone', 'Çukur', 'Kurtlar Vadisi', 'Muhteşem Yüzyıl', 'Diriliş Ertuğrul', 'Alparslan'];
const liveNames = ['TRT 1', 'ATV', 'Show TV', 'Star TV', 'Kanal D', 'Fox TV', 'TV8', 'Kanal 7', 'TRT Spor', 'beIN Sports 1', 'beIN Sports 2', 'S Sport', 'TRT Haber', 'NTV', 'CNN Türk', 'Habertürk', 'Bloomberg HT', 'TRT Belgesel', 'National Geographic', 'Discovery Channel'];
const sportsNames = ['beIN Sports 1 HD', 'beIN Sports 2 HD', 'beIN Sports 3 HD', 'S Sport HD', 'S Sport 2 HD', 'TRT Spor HD', 'TRT Spor 2', 'Euro Sport 1', 'Euro Sport 2', 'NBA TV', 'ESPN', 'Fox Sports', 'Sky Sports', 'DAZN', 'Sport TV'];
const docNames = ['National Geographic', 'Discovery Channel', 'Animal Planet', 'History Channel', 'BBC Earth', 'TRT Belgesel', 'Nat Geo Wild', 'Science Channel', 'Smithsonian', 'Curiosity Stream'];
const kidsNames = ['Cartoon Network', 'Disney Channel', 'Nickelodeon', 'TRT Çocuk', 'Minika Go', 'Minika Çocuk', 'Baby TV', 'Boomerang', 'Disney Junior', 'Nick Jr'];
const musicNames = ['MTV', 'VH1', 'Power TV', 'Kral TV', 'Kral Pop', 'Number1 TV', 'Dream TV', 'Joy Türk', 'MTV Hits', 'Mezzo'];
const newsNames = ['TRT Haber', 'NTV', 'CNN Türk', 'Habertürk', 'A Haber', 'TGRT Haber', 'TV 360', 'Halk TV', 'Tele 1', 'BBC World News', 'Al Jazeera', 'France 24', 'DW', 'Bloomberg HT', 'Euronews'];

const movieDescriptions = [
  'Oscar ödüllü, tüm zamanların en iyi filmi olarak kabul gören başyapıt.',
  'Sinema tarihine altın harflerle yazılan, derin duygusal bir hikaye.',
  'Aksiyon ve gerilim dolu, nefes kesen bir macera.',
  'Görselliği ve senaryosuyla büyüleyen bilim kurgu şaheseri.',
  'İzleyiciyi sonuna kadar ekrana kilitleyen epik bir yapım.',
  'Ödüllü yönetmenin elinden çıkan unutulmaz bir sinema deneyimi.',
  'Karakter derinliği ve atmosferiyle öne çıkan dramatik bir şaheser.',
];
const seriesDescriptions = [
  'Emmy ödüllü, dünyanın dört bir yanında milyonlarca izleyiciye ulaşan fenomen dizi.',
  'Bağımlılık yapan senaryosu ve güçlü kadrosuyla dikkat çeken yapım.',
  'Her bölümde yeni bir sürpriz sunan gerilim dolu dizi.',
  'Fantastik dünyasıyla izleyiciyi başka bir evrene taşıyan dizi.',
  'Türk seyircisinin gönlünde taht kuran ulusal yapım.',
];
const liveDescriptions = [
  'Türkiye\'nin en çok izlenen yayın kanalı, 7/24 canlı yayın.',
  'Eğlence ve haber programlarıyla günün her saati yanınızda.',
  'Canlı dizi, film ve magazin haberleriyle dolu.',
  '24 saat kesintisiz haber ve tartışma programları.',
  'Spor, haber ve eğlence bir arada.',
];

const qualities = ['4K', 'FHD', 'HD', 'SD'];
const years = ['2024', '2023', '2022', '2021', '2020', '2019'];
// Real HLS test streams
const hlsStreams = [
  'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
  'https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8',
  'https://playertest.longtailvideo.com/adaptive/wowzaid3/playlist.m3u8',
  'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
];

const generateChannels = (
  category: string,
  prefix: string,
  names: string[],
  descriptions: string[],
  isLive: boolean = false,
  count?: number
): Channel[] => {
  const limit = count ?? names.length;
  return Array.from({ length: Math.min(limit, names.length) }, (_, i) => ({
    id: `${prefix}-${i}`,
    name: names[i],
    logo: `https://picsum.photos/seed/${prefix}${i * 3 + 7}/300/450`,
    backdrop: `https://picsum.photos/seed/${prefix}bg${i * 2}/1280/720`,
    category,
    url: hlsStreams[i % hlsStreams.length],
    description: descriptions[i % descriptions.length],
    rating: Math.round((7 + Math.random() * 3) * 10) / 10,
    year: years[Math.floor(Math.random() * years.length)],
    duration: isLive ? 'CANLI' : `${Math.floor(90 + Math.random() * 60)} dk`,
    quality: qualities[Math.floor(Math.random() * qualities.length)],
    isLive,
    isFavorite: false,
  }));
};

export const categories: Category[] = [
  {
    id: 'live',
    name: 'Canlı TV',
    icon: '📺',
    channels: generateChannels('Canlı TV', 'live', liveNames, liveDescriptions, true),
  },
  {
    id: 'movies',
    name: 'Filmler',
    icon: '🎬',
    channels: generateChannels('Filmler', 'movie', movieNames, movieDescriptions, false),
  },
  {
    id: 'series',
    name: 'Diziler',
    icon: '📀',
    channels: generateChannels('Diziler', 'series', seriesNames, seriesDescriptions, false),
  },
  {
    id: 'sports',
    name: 'Spor',
    icon: '⚽',
    channels: generateChannels('Spor', 'sport', sportsNames, liveDescriptions, true),
  },
  {
    id: 'documentary',
    name: 'Belgesel',
    icon: '🌍',
    channels: generateChannels('Belgesel', 'doc', docNames, movieDescriptions, false),
  },
  {
    id: 'kids',
    name: 'Çocuk',
    icon: '🧸',
    channels: generateChannels('Çocuk', 'kid', kidsNames, ['Çocuklar için eğlenceli animasyon ve eğitici içerikler.', 'Renkli dünyasıyla çocukların favorisi.'], false),
  },
  {
    id: 'music',
    name: 'Müzik',
    icon: '🎵',
    channels: generateChannels('Müzik', 'music', musicNames, ['En hit şarkılar ve canlı konser yayınları.', 'Müziği sevenler için 7/24 yayın.'], true),
  },
  {
    id: 'news',
    name: 'Haber',
    icon: '📰',
    channels: generateChannels('Haber', 'news', newsNames, ['7/24 son dakika haberleri.', 'Dünya gündemine anında erişim.'], true),
  },
];

// Featured content for Movies page
export const featuredMovies: Channel[] = [
  {
    id: 'fm-1',
    name: 'Oppenheimer',
    logo: 'https://picsum.photos/seed/oppenheimer300/300/450',
    backdrop: 'https://picsum.photos/seed/oppenbg1920/1280/720',
    category: 'Filmler',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    description: 'J. Robert Oppenheimer\'ın hayatını anlatan Christopher Nolan\'ın epik biyografik filmi. Atom bombasının baş mimarının çöküşünü ve rövanşını konu alıyor.',
    rating: 9.2,
    year: '2023',
    duration: '180 dk',
    quality: '4K',
    isLive: false,
  },
  {
    id: 'fm-2',
    name: 'Dune: Part Two',
    logo: 'https://picsum.photos/seed/dune300/300/450',
    backdrop: 'https://picsum.photos/seed/dunebg1920/1280/720',
    category: 'Filmler',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    description: 'Frank Herbert\'in efsanevi bilim kurgu romanından uyarlanan devam filmi. Paul Atreides çölde hayatta kalmak için Fremen\'lerle ittifak kuruyor.',
    rating: 8.8,
    year: '2024',
    duration: '166 dk',
    quality: '4K',
    isLive: false,
  },
  {
    id: 'fm-3',
    name: 'Joker: Folie à Deux',
    logo: 'https://picsum.photos/seed/joker300/300/450',
    backdrop: 'https://picsum.photos/seed/jokerbg1920/1280/720',
    category: 'Filmler',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    description: 'Todd Phillips\'ın devam niteliğindeki müzikal psikolojik filmi. Joaquin Phoenix yeniden Joker rolünde izleyicileri büyülüyor.',
    rating: 8.1,
    year: '2024',
    duration: '138 dk',
    quality: 'FHD',
    isLive: false,
  },
];

// Featured content for Series page
export const featuredSeries: Channel[] = [
  {
    id: 'fs-1',
    name: 'The Last of Us — S2',
    logo: 'https://picsum.photos/seed/lastofus300/300/450',
    backdrop: 'https://picsum.photos/seed/lastbg1920/1280/720',
    category: 'Diziler',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    description: 'Kıyamet sonrası dünyada Joel ve Ellie\'nin zorlu yolculuğunun ikinci sezonunda yeni karakterler ve tehlikeler karşılarına çıkıyor.',
    rating: 9.4,
    year: '2025',
    duration: '55 dk/bölüm',
    quality: '4K',
    isLive: false,
  },
  {
    id: 'fs-2',
    name: 'Squid Game — S3',
    logo: 'https://picsum.photos/seed/squidgame300/300/450',
    backdrop: 'https://picsum.photos/seed/squidbg1920/1280/720',
    category: 'Diziler',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    description: 'Dünyanın en çok izlenen Kore dizisi geri döndü. Gi-hun\'un hikayesi yeni oyunlar ve sürprizlerle devam ediyor.',
    rating: 9.1,
    year: '2025',
    duration: '50 dk/bölüm',
    quality: '4K',
    isLive: false,
  },
  {
    id: 'fs-3',
    name: 'Diriliş Ertuğrul',
    logo: 'https://picsum.photos/seed/ertugrul300/300/450',
    backdrop: 'https://picsum.photos/seed/ertugrulbg1920/1280/720',
    category: 'Diziler',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    description: 'Osmanlı öncesini konu alan ve dünya genelinde milyarlarca izlenmeye ulaşan, Türkiye\'nin en büyük dizi yapımı.',
    rating: 9.0,
    year: '2019',
    duration: '130 dk/bölüm',
    quality: 'FHD',
    isLive: false,
  },
];

// Featured content for Live TV page
export const featuredLive: Channel[] = [
  {
    id: 'fl-1',
    name: 'beIN Sports 1 HD',
    logo: 'https://picsum.photos/seed/bein300/300/450',
    backdrop: 'https://picsum.photos/seed/beinbg1920/1280/720',
    category: 'Spor',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    description: 'Süper Lig, UEFA Şampiyonlar Ligi, La Liga ve daha fazlası. Tüm heyecanlı maçları canlı ve HD kalitede izleyin.',
    rating: 9.0,
    year: '2024',
    duration: 'CANLI',
    quality: 'FHD',
    isLive: true,
  },
  {
    id: 'fl-2',
    name: 'TRT 1 HD',
    logo: 'https://picsum.photos/seed/trt300/300/450',
    backdrop: 'https://picsum.photos/seed/trtbg1920/1280/720',
    category: 'Canlı TV',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    description: 'Türkiye Radyo ve Televizyon Kurumu\'nun ana kanalı. Haber, belgesel, dizi ve eğlence programları.',
    rating: 8.5,
    year: '2024',
    duration: 'CANLI',
    quality: 'HD',
    isLive: true,
  },
  {
    id: 'fl-3',
    name: 'CNN Türk',
    logo: 'https://picsum.photos/seed/cnnt300/300/450',
    backdrop: 'https://picsum.photos/seed/cnntbg1920/1280/720',
    category: 'Haber',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    description: '7/24 son dakika haberleri, özel programlar ve dünya gündemi ile Türkiye\'nin önde gelen haber kanalı.',
    rating: 8.2,
    year: '2024',
    duration: 'CANLI',
    quality: 'HD',
    isLive: true,
  },
];

export const getAllChannels = (): Channel[] => {
  return categories.flatMap(c => c.channels);
};

export const searchChannels = (query: string): Channel[] => {
  const lower = query.toLowerCase();
  return getAllChannels().filter(c =>
    c.name.toLowerCase().includes(lower) ||
    c.category.toLowerCase().includes(lower)
  );
};
